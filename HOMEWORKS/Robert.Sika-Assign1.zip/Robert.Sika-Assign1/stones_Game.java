import java.sql.SQLOutput;
import java.util.Scanner;

public class stones_Game{

    public static int checkInput(int x, int y, int z)
    {
        Scanner input = new Scanner(System.in);
        if (z==1){
            //this block validates the starting number of stones
            while ((x <= 0) || (x % 2 == 0) || (x == 1))
            {
                System.out.println("Number must be positive, odd, and not 1.");
                System.out.print("Enter starting number of stones: ");
                x = input.nextInt();
            }
        }
        else {
            //this block validates the number of stones picked each turn
            while ((x <= 0) || (x > y))
            {
                System.out.print("You must pick between 1 stone and " + y + " stones: ");
                x = input.nextInt();
            }
        }
        return x;
    }
    public static void main(String[] args){
        System.out.println("Enter starting number of stones: ");
        Scanner input = new Scanner(System.in);
        int initialStones = input.nextInt();
        initialStones = checkInput(initialStones,0,1);
        int player1Stones = 0, player2Stones = 0, playNum = 0;
        int lowerStones = 1;
        int initialPick = 0;
        System.out.println("Player 1\nEnter your name here: ");
        String player1Name = input.next();
        System.out.println("Player 2\nEnter your name here: ");
        String player2Name = input.next();

        while(initialStones > 0){
            System.out.println("\nSummary\n");
            if (playNum == 0){
                //first play
                int upperStones = (initialStones/2);
                System.out.println(String.format("%s has %d stones", player1Name, player1Stones));
                System.out.println(String.format("%s has %d stones", player2Name, player2Stones));
                System.out.println(String.format("There are %d stones left in the pile.", initialStones));
                System.out.println(player1Name + ", choose between " + lowerStones + " stone and " + upperStones
                        + " stones: ");
                //get and validate the number of stones a player picks
                initialPick = checkInput(input.nextInt(), upperStones,0);
                initialStones -= initialPick;
                player1Stones += initialPick;
                // if double the previous pick is greater than the number of stones left,
                // set the upper limit to the number of stones left
                upperStones = ((2*initialPick)>initialStones)?(initialStones):(initialPick);
                playNum += 1;
                System.out.println("\nSummary\n");
                System.out.println(player1Name + " has " + player1Stones + " stones");
                System.out.println(player2Name + " has " + player2Stones + " stones");
                System.out.println("There are " + initialStones + " stones left in the pile.");
                System.out.println(player2Name + ", choose between " + lowerStones + " and " + upperStones
                        + " stones: ");
                initialPick = checkInput(input.nextInt(), upperStones,0);
                initialStones -= initialPick;
                player2Stones += initialPick;

                playNum++;

        }else{
                int upperStones = ((2 * initialPick) > initialStones) ? (upperStones = initialStones) : (2 * initialPick);
                System.out.println(String.format("%s has %d stones", player1Name, player1Stones));
                System.out.println(String.format("%s has %d stones", player2Name, player2Stones));
                System.out.println(String.format("There are %d stones left in the pile.", initialStones));
                System.out.println(player1Name + ", choose between " + lowerStones + " stone and " + upperStones + " stones: ");
                initialPick = checkInput(input.nextInt(),upperStones,0);
                initialStones -= initialPick;
                player1Stones += initialPick;

                if (initialStones == 0){
                    break;
                }
                upperStones = ((2 * initialPick)>initialStones)?(upperStones = initialStones):(2*initialPick);
                System.out.println("\nSummary\n");
                System.out.println(String.format("%s has %d stones", player1Name, player1Stones));
                System.out.println(String.format("%s has %d stones", player2Name, player2Stones));
                System.out.println(String.format("There are %d stones left in the pile.", initialStones));
            System.out.println(player1Name + ", choose between " + lowerStones + " stone and " + upperStones + " stones: ");
            initialPick = checkInput(input.nextInt(),upperStones,0);
            initialStones -= initialPick;
            player2Stones += initialPick;


        }}
        System.out.println("\nSummary\n");
        System.out.println(String.format("%s has %d stones", player1Name, player1Stones));
        System.out.println(String.format("%s has %d stones", player2Name, player2Stones));
        System.out.println(String.format("There are no stones left in the pile."));

        if ((player1Stones % 2) == 1){
            System.out.println(player1Name + " wins!");
        }else {
            System.out.println(player2Name + "wins!");
        }
        input.close();


    }
}
