public class Person {
    //Declare variables
    private String name;
    private int age;
    private String gender;




    //create a class constructor
    //    1. Write a default constructor for a Person that sets name to the string “No name yet”,
    //       age to zero and gender to a random choice between male and female
    public Person () {
        this.name = "No name yet";
        this.age = 0;
        this.gender = Math.random() < 0.5 ? "male":"female";
    }
    //   2. Write a second constructor for Person that sets name to a given string,
    //      age to a given integer value, and gender to a given value
    public Person(String name, int age, String gender){
        this.name = name;
        this.age = age;
        this.gender = gender;
    }






    //name mutator method
    public void setName(String name) {
        this.name = name;
    }
    //name accessor method
    public String getName() {
        return name;
    }





    //age mutator method
    public void setAge(int age) {
        this.age = age;
    }
    //age accessor method
    public int getAge() {
        return age;
    }







    //gender mutator method
    public void setGender(String gender) {
        this.gender = gender;
    }





    //gender accessor method
    public String getGender() {
        return gender;
    }


    //methods to the Person class from the previous step to perform the following tasks:

    //Test whether two Person objects are equal (have the same name and age)
    public boolean Equal(Person other){
        if(getName().equals(other.getName()) && getAge() == other.getAge()){
            return true;
        }else{
            return false;
        }
    }

    //Test whether two Person objects have the same name
    public boolean sameName(Person other){
        if(getName().equals(other.getName())){
            return true;
        }else{
            return false;
        }
    }

    //Test whether two Person objects are the same age
    public boolean sameAge(Person other){
        if(getAge() == (other.getAge())){
            return true;
        }else{
            return false;
        }
    }

    //Test whether one Person object is older than another
    public boolean older(Person other){
        if (getAge() > other.getAge()){
            return true;
        }else{
            return false;
        }
    }

    //Test whether one Person object is younger than another
    public boolean younger(Person other){
        if (getAge() < other.getAge()){
            return true;
        }else{
            return false;
        }
    }
}