public class TestCar {
    public static void main(String[] args) {
        Person driver = new Person("John", 25 ,"male");
        Person passenger1 = new Person("Jane", 22,"female");
        Person passenger2 = new Person("Jim", 20, "male");
        Person passenger3 = new Person("Jessica", 19,"female");
        Person passenger4 = new Person("Julie", 17,"female");
        Car car = new Car(driver);

        System.out.println(car.hasDriver()); // should print "Has driver: true"
        System.out.println(car.hasPassengers()); // should print "Has passengers: false"
        System.out.println(car.isEmpty()); // should print "Is empty: false"
        System.out.println(car.isFull()); // should print "Is full: false"

        System.out.println(car.addPassenger(passenger1)); // should print "Adding passenger: true"
        System.out.println(car.hasPassengers()); // should print "Has passengers: true"
        System.out.println(car.addPassenger(passenger2)); // should print "Adding passenger: true"
        System.out.println(car.addPassenger(passenger3)); // should print "Adding passenger: true"
        System.out.println(car.addPassenger(passenger4)); // should print "Adding passenger: false"
        System.out.println(car.isFull()); // should print "Is full: true"

        System.out.println(car.getNumOccupants()); // should print "Number of occupants: 4"
//        car.listRiders(); // should print the details of driver and all passengers
    }
}