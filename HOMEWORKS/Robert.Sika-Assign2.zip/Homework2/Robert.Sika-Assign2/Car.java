public class Car{
    // Part A
    //instance variable called driver
    private Person driver;
    // instance variable called frontSeatPassenger
    private Person frontSeatPassenger;
    //instance variables backSeatPassenger1
    private Person backseatPassenger1;
    //instance variables backSeatPassenger2
    private Person backseatPassenger2;
    //instance variables backSeatPassenger3
    private Person backseatPassenger3;
    //a string instance variable represents the license plate number of the car
    private String licencePlateNumber;
    private int totalOccupant;


    public Car() {
        this.driver = null;
        this.frontSeatPassenger = null;
        this.backseatPassenger1 = null;
        this.backseatPassenger2 = null;
        this.backseatPassenger3 = null;
    }



    public Car(Person driver){
        if(driver.getAge() > 18){
            this.driver = driver;
            this.frontSeatPassenger = null;
            this.backseatPassenger1 = null;
            this.backseatPassenger2 = null;
            this.backseatPassenger3 = null;
        }else{
            System.out.println("Error");
            System.exit(1);
        }

    }

    public boolean hasDriver(){
        if(driver != null){
            return true;
        }else{
            return false;
        }
    }

    public boolean hasPassengers(){
        if(frontSeatPassenger != null || backseatPassenger3 != null || backseatPassenger1 != null || backseatPassenger2 != null){
            return true;
        }else{
            return false;
        }
    }

    public boolean isEmpty(){
        if(hasDriver() == false && hasPassengers() == false){
            return true;
        }else{
            return false;
        }
    }

    public boolean isFull(){
        if(hasDriver()== true && frontSeatPassenger != null && backseatPassenger3 != null && backseatPassenger1 != null && backseatPassenger2 != null){
            return true;
        }else{
            return false;
        }
    }

    public boolean setDriver(Person driver){
        if(driver.getAge() >18){
            this.driver = driver;
            return true;
        }else{
            return false;
        }
    }

    public boolean addPassenger(Person Passenger){
        if(frontSeatPassenger == null){
            this.frontSeatPassenger = Passenger;
            return true;
        } else if (backseatPassenger1 == null)  {
            this.backseatPassenger1 = Passenger;
            return true;

        } else if (backseatPassenger2 == null) {
            this.backseatPassenger2 = Passenger;
            return true;

        } else if (backseatPassenger3 == null) {
            this.backseatPassenger3 = Passenger;
            return true;

        }else{
            return false;
        }
    }

    public int getNumOccupants(){
        if(hasDriver() == true){
            this.totalOccupant +=1;
        }
        if(frontSeatPassenger != null){
            this.totalOccupant +=1;
        }
        if(backseatPassenger1 != null){
            this.totalOccupant += 1;
        }
        if(backseatPassenger2 != null){
            this.totalOccupant += 1;
        }
        if(backseatPassenger3 != null){
            this.totalOccupant += 1;
        }

        return totalOccupant;
    }



}