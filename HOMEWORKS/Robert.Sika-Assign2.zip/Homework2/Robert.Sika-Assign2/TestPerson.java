public class TestPerson {
    public static void main(String[] args) {
        //Creating Objects
        Person Robert = new Person("Robert", 768, "male");
        Person Anderson = new Person("Anderson", 23, "them");
        Person Fleek = new Person("Fleek", 98, "female");

        //Test whether two Person objects are equal (have the same name and age)
        System.out.println(Robert.Equal(Anderson));
        System.out.println(Robert.sameAge(Anderson));

        //Test whether two Person objects are equal (have the same name and age)
        System.out.println(Robert.Equal(Fleek));
        System.out.println(Robert.sameAge(Fleek));


        //Test whether two Person objects have the same name
        System.out.println(Robert.sameName(Anderson));
        System.out.println(Robert.sameName(Fleek));

        //Test whether two Person objects are the same age
        System.out.println(Robert.sameAge(Anderson));
        System.out.println(Robert.sameAge(Fleek));

        //Test whether one Person object is older than another
        System.out.println(Robert.older(Anderson));
        System.out.println(Robert.older(Fleek));

        //Test whether one Person object is younger than another
        System.out.println(Robert.younger(Anderson));
        System.out.println(Robert.younger(Fleek));


/*
        Robert.setName("Rita");  //changing name
        Robert.getName();  //returning name
        Robert.setAge(30);  //changing age
        Robert.setGender("female");   //changing gender
        Robert.getGender();  //returning gender

        Person Joo = new Person("Joo", 12, "male");  //creating an object named Joo
        Joo.getPerson();  //returning attributes of Joo
*/
    }



}
